<?php
session_start();

// Redirect user to login page if not logged in
if (!isset($_SESSION["user_id"])) {
    header("location: login.php");
    exit;
}

// Include database configuration
require_once "db_config.php";

// Retrieve input data from the POST request
$data = json_decode(file_get_contents("php://input"), true);
$action = $data['action'];

if ($action === "create") {
    // Prepare insert query for student_track_record table
    $insertTrackRecordQuery = "INSERT INTO student_track_record 
        (generated_id, department, mentor_name, mentor_designation, class, batch, semester, academic_year, overall_observation, total_number_of_students, action_taken, created_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind parameters
    if ($stmt = $mysqli->prepare($insertTrackRecordQuery)) {
        $stmt->bind_param(
            "sssssssssssi",
            $data['generatedId'],
            $data['department'],
            $data['mentorName'],
            $data['mentorDesignation'],
            $data['class'],
            $data['batch'],
            $data['semester'],
            $data['academicYear'],
            $data['overallObservation'],
            $data['totalNumberOfStudents'],
            $data['actionTaken'],
            $_SESSION["user_id"]
        );

        // Execute the statement
        if ($stmt->execute()) {
            // Get the ID of the inserted record
            $strId = $stmt->insert_id;

            // Close the statement
            $stmt->close();

            // Return the ID of the inserted record
            echo json_encode(array("success" => true, "strId" => $strId));
        } else {
            // Error occurred while executing the statement
            echo json_encode(array("success" => false, "message" => "Error occurred while adding student track record"));
        }
    } else {
        // Error occurred while preparing the statement
        echo json_encode(array("success" => false, "message" => "Error occurred while preparing statement"));
    }
} elseif ($action === "edit") {
    // Prepare update query for student_track_record table
    $updateTrackRecordQuery = "UPDATE student_track_record 
        SET department=?, mentor_name=?, mentor_designation=?, class=?, batch=?, semester=?, academic_year=?, overall_observation=?, total_number_of_students=?, action_taken=?, updated_by =?
        WHERE id=?";

    // Prepare and bind parameters
    if ($stmt = $mysqli->prepare($updateTrackRecordQuery)) {
        $stmt->bind_param(
            "ssssssssssii",
            $data['department'],
            $data['mentorName'],
            $data['mentorDesignation'],
            $data['class'],
            $data['batch'],
            $data['semester'],
            $data['academicYear'],
            $data['overallObservation'],
            $data['totalNumberOfStudents'],
            $data['actionTaken'],
            $_SESSION["user_id"],
            $data['updStrId']
        );

        // Execute the statement
        if ($stmt->execute()) {
            // Close the statement
            $stmt->close();

            // Delete records from student_record_details table
            $deleteRecordDetailsQuery = "DELETE FROM student_record_details WHERE str_id=?";
            if ($stmtDelete = $mysqli->prepare($deleteRecordDetailsQuery)) {
                $stmtDelete->bind_param("i", $data['updStrId']);
                $stmtDelete->execute();
                $stmtDelete->close();
            }

            // Return success
            echo json_encode(array("success" => true));
        } else {
            // Error occurred while executing the statement
            echo json_encode(array("success" => false, "message" => "Error occurred while updating student track record"));
        }
    } else {
        // Error occurred while preparing the statement
        echo json_encode(array("success" => false, "message" => "Error occurred while preparing statement"));
    }
}

// Close the database connection
$mysqli->close();
?>