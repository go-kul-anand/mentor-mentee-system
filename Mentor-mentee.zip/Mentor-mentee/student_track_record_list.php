<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include your database connection code here

// Fetch user information from the database if needed
// Replace this with your actual database query
$user_id = $_SESSION['user_id'];
// Example query to fetch user info
// $query = "SELECT * FROM user WHERE id = $user_id";
// Execute your query and fetch user data as needed

require_once "db_config.php";

// Function to get user name from user id
function getUserName($mysqli, $userId) {
    if (!empty($userId)) {
        $sql = "SELECT name FROM user WHERE id = $userId";
        $result = mysqli_query($mysqli, $sql);
        $row = mysqli_fetch_assoc($result);
        return $row['name'];
    } else {
        return "";
    }
}


$filter_by = $_GET["filter_by"];
$stu_id = '';
$stu_name = '';

// Check if mode is "view"
if ($filter_by === "student") {

    $stu_id = $_GET["stu_id"];
    $stu_name = $_GET["stu_name"];
}
?>

<!-- Access the JSON data in your HTML tags -->
<input type="hidden" id="filter_by" value="<?php echo $filter_by; ?>">
<input type="hidden" id="stu_id" value="<?php echo $stu_id; ?>">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Track Records</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div id="loadingOverlay" class="position-fixed top-0 start-0 w-100 h-100 bg-white opacity-75 d-none d-flex
    justify-content-center align-items-center" style="z-index: 9999;">
        <!-- Spinner -->
        <div class="spinner-border text-primary" role="status">
            <!-- <span class="visually-hidden">Loading...</span> -->
        </div>
    </div>
    <div class="container">
        <h1>Student Track Records</h1>
        <a href="create_str.php?mode=create" class="btn btn-success">Add Student Track Record</a>
        <a href="index.php" class="btn btn-primary">Back to Dashboard</a>
        <a href="logout.php" class="btn btn-danger">Logout</a>
        <?php if ($filter_by === "student"): ?>
            <hr>
            <div class="col-md-12">
                <label>Student Name: <?php echo $stu_name; ?></label>
            </div>
        <?php endif; ?>
        <hr>
        <table id="studentRecordsTable" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Actions</th>
                    <th>Record ID</th>
                    <th>Department</th>
                    <th>Mentor Name</th>
                    <th>Mentor Designation</th>
                    <th>Class</th>
                    <th>Batch</th>
                    <th>Semester</th>
                    <th>Academic Year</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php

                $sql = "";

                // Check the value of $filter_by
                if ($filter_by == 'none') {
                    // If filter_by is 'none',
                    $sql = "SELECT * FROM student_track_record WHERE created_by = ".$_SESSION['user_id']." ORDER BY created_at DESC";
                } else if ($filter_by == 'student') {
                    // If filter_by is 'student', build the SQL query
                    $sql = "SELECT * FROM student_track_record WHERE id IN (SELECT DISTINCT str_id FROM student_record_details WHERE student_id = $stu_id) ORDER BY created_at DESC";
                }

                $result = mysqli_query($mysqli, $sql);
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>
                            <center>
                                <a href='create_str.php?mode=view&gen_id={$row['generated_id']}' class='btn btn-primary btn-sm' style='margin-bottom: 5px;'>Full Report</a>
                                <button class='btn btn-success btn-sm viewBtn' data-id='{$row['id']}' data-bs-toggle='modal' data-bs-target='#viewModal'><i class='fas fa-eye'></i></button>
                                <a href='create_str.php?mode=edit&gen_id={$row['generated_id']}' class='btn btn-secondary btn-sm' style='margin-bottom: 5px;'>Edit Report</a>
                                <button class='btn btn-danger btn-sm deleteBtn' data-id='{$row['id']}' data-toggle='modal' data-target='#deleteModal'><i class='fas fa-trash'></i></button>
                            </center>
                            </td>
                            <td>{$row['generated_id']}</td>
                            <td>{$row['department']}</td>
                            <td>{$row['mentor_name']}</td>
                            <td>{$row['mentor_designation']}</td>
                            <td>{$row['class']}</td>
                            <td>{$row['batch']}</td>
                            <td>{$row['semester']}</td>
                            <td>{$row['academic_year']}</td>
                            <td>{$row['created_at']}</td>
                        </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- View Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel">View Student Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Responsive DataTable for Student Record Details -->
                    <table id="studentDetailsTable" class="display" style="width:100%">
                        <!-- Table body will be populated dynamically using jQuery -->
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this record?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Close">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <!-- Custom Script -->
    <script src="main.js"></script>

    <script>
        $(document).ready(function() {

            var filterBy = $('#filter_by').val();
            var stuId = $('#stu_id').val();

            // Initialize DataTable
            $('#studentRecordsTable').DataTable({
                "lengthMenu": [ [10], [10] ], // Restrict to show only 10 entries
                "searching": false, // Disable search
                "ordering": false // Disable sorting
            });

            // Handle View Button Click
            $('.viewBtn').click(function() {
                showLoadingOverlay();
                var recordId = $(this).data('id');
                $.ajax({
                    url: 'fetch_student_record_details.php',
                    type: 'GET',
                    data: { recordId: recordId },
                    success: function(response) {
                        hideLoadingOverlay();
                        $('#studentDetailsTable').html(response);
                    }
                });
            });

            // Handle Delete Button Click
            $('.deleteBtn').click(function() {
                var recordId = $(this).data('id');
                $('#confirmDeleteBtn').attr('data-id', recordId);
                $('#deleteModal').modal('show'); // Show the modal
            });

            // Handle Confirm Delete Button Click
            $('#confirmDeleteBtn').click(function() {
                showLoadingOverlay();
                var recordId = $(this).data('id');
                $.ajax({
                    url: 'delete_student_track_record.php',
                    type: 'POST',
                    data: { recordId: recordId },
                    success: function(response) {
                        hideLoadingOverlay();
                        location.reload();
                    }
                });
            });
        });
    </script>
</body>
</html>
