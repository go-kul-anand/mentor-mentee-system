<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("location: login.php");
    exit;
}

require_once "db_config.php";
// Check if recordId is set
if(isset($_POST["recordId"])) {
    $recordId = $_POST["recordId"];

    // Delete associated details first
    $sqlDeleteDetails = "DELETE FROM student_record_details WHERE str_id = $recordId";
    if (mysqli_query($mysqli, $sqlDeleteDetails)) {
        // Delete the student track record
        $sqlDeleteRecord = "DELETE FROM student_track_record WHERE id = $recordId";
        if (mysqli_query($mysqli, $sqlDeleteRecord)) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . mysqli_error($mysqli);
        }
    } else {
        echo "Error deleting details: " . mysqli_error($mysqli);
    }
}
?>
