<?php
session_start();

// Include database configuration
require_once "db_config.php";

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data received from the client
    $data = json_decode(file_get_contents("php://input"));

    // Check if all required fields are provided
    if (isset($data->strId) && isset($data->rollNumber) && isset($data->studentName) && isset($data->cgpa) && isset($data->numArrears) && isset($data->paperPresentation) && isset($data->projectHackathon) && isset($data->extracurricularActivities) && isset($data->onlineCertifications) && isset($data->counseling) && isset($data->signatureOfStudent)) {

        // Sanitize input data
        $strId = mysqli_real_escape_string($mysqli, $data->strId);
        $rollNumber = mysqli_real_escape_string($mysqli, $data->rollNumber);
        // Assuming $mysqli is your mysqli connection object

        // Escape the roll number to prevent SQL injection
        $rollNumber = mysqli_real_escape_string($mysqli, $data->rollNumber);
        $studentName = mysqli_real_escape_string($mysqli, $data->studentName);
        $cgpa = mysqli_real_escape_string($mysqli, $data->cgpa);
        $numArrears = mysqli_real_escape_string($mysqli, $data->numArrears);
        $paperPresentation = mysqli_real_escape_string($mysqli, $data->paperPresentation);
        $projectHackathon = mysqli_real_escape_string($mysqli, $data->projectHackathon);
        $extracurricularActivities = mysqli_real_escape_string($mysqli, $data->extracurricularActivities);
        $onlineCertifications = mysqli_real_escape_string($mysqli, $data->onlineCertifications);
        $counseling = mysqli_real_escape_string($mysqli, $data->counseling);
        $signatureOfStudent = mysqli_real_escape_string($mysqli, $data->signatureOfStudent);

        // Get user ID from session
        $createdBy = $_SESSION["user_id"];

        // Prepare an insert statement
        $sql = "INSERT INTO student_record_details (str_id, student_id, roll_number, name, cgpa, num_arrears, paper_presentation, project_hackathon, extracurricular_activities, online_certifications, counseling, signature_of_student, created_by) 
                VALUES ('$strId', (SELECT id FROM student WHERE roll_number = '$rollNumber'), '$rollNumber', '$studentName', '$cgpa', '$numArrears', '$paperPresentation', '$projectHackathon', '$extracurricularActivities', '$onlineCertifications', '$counseling', '$signatureOfStudent', '$createdBy')";

        // Execute the insert statement
        if (mysqli_query($mysqli, $sql)) {
            // Record inserted successfully
            echo json_encode(array("message" => "Student details inserted successfully"));
        } else {
            // Error occurred while inserting record
            http_response_code(500);
            echo json_encode(array("error" => "Error occurred while inserting record: " . mysqli_error($mysqli)));
        }

    } else {
        // Required parameters are missing
        http_response_code(400);
        echo json_encode(array("error" => "Missing required parameters"));
    }
} else {
    // Invalid request method
    http_response_code(405);
    echo json_encode(array("error" => "Invalid request method. Only POST requests are allowed"));
}

// Close database connection
mysqli_close($mysqli);
?>
