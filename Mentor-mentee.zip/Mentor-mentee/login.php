<?php
session_start();

$login_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "db_config.php";

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, name, password, department FROM user WHERE user_name = ?";
    if ($stmt = $mysqli->prepare($sql)) {
        $stmt->bind_param("s", $param_username);
        $param_username = $username;

        if ($stmt->execute()) {
            $stmt->store_result();

            if ($stmt->num_rows == 1) {
                $stmt->bind_result($id, $name, $hashed_password, $department);
                if ($stmt->fetch()) {
                    if ($password == $hashed_password) {
                        $_SESSION["user_id"] = $id;
                        $_SESSION["username"] = $username;
                        $_SESSION["name"] = $name;
                        $_SESSION["department"] = $department;
                        header("location: index.php");
                        exit;
                    } else {
                        $login_err = "Invalid username or password.";
                    }
                }
            } else {
                $login_err = "Invalid username or password.";
            }
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }

        $stmt->close();
    }

    $mysqli->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentor Mentee System - Student Track Record(STR) - LOGIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <?php require_once "./bytes/header.php"; ?>

    <div class="container login-container mb-5">
        <h3 class="text-center">Mentor Mentee System - Student Track Record(STR)</h3>
        <h3 class="text-center">LOGIN</h3>
        <div class="login-form">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" onsubmit="showLoadingOverlay()">
                <div class="mb-3">
                    <div class="form-group">
                        <label for="username">User Name</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>
                <div class="form-group">
                    <?php if (!empty($login_err)) : ?>
                        <div class="text-danger"><?php echo $login_err; ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>