<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include your database connection code here

// Fetch user information from the database if needed
// Replace this with your actual database query
$user_id = $_SESSION['user_id'];
// Example query to fetch user info
// $query = "SELECT * FROM user WHERE id = $user_id";
// Execute your query and fetch user data as needed

require_once "db_config.php";

// Check if roll number parameter is set
if (isset($_GET['roll_number'])) {
    // Sanitize the input to prevent SQL injection
    $rollNumber = mysqli_real_escape_string($mysqli, $_GET['roll_number']);

    // Query to fetch student data based on roll number
    $query = "SELECT name, cgpa, arrear_count FROM student WHERE roll_number = '$rollNumber'";

    // Perform the query
    $result = mysqli_query($mysqli, $query);

    if ($result) {
        // Fetch the data
        $row = mysqli_fetch_assoc($result);

        if ($row) {
            // Student data found, return success and data
            $response = array(
                'success' => true,
                'name' => $row['name'],
                'cgpa' => $row['cgpa'],
                'arrears' => $row['arrear_count']
            );
            echo json_encode($response);
        } else {
            // No data found for the given roll number
            $response = array(
                'success' => false,
                'message' => 'No student found with the provided roll number.'
            );
            echo json_encode($response);
        }
    } else {
        // Query execution failed
        $response = array(
            'success' => false,
            'message' => 'Error executing query.'
        );
        echo json_encode($response);
    }
} else {
    // Roll number parameter not provided
    $response = array(
        'success' => false,
        'message' => 'Roll number parameter is missing.'
    );
    echo json_encode($response);
}
?>
