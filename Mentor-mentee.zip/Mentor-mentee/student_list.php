<?php
session_start();

// Redirect user to dashboard if already logged in
if(isset($_SESSION["user_id"]) && $_SESSION["user_id"] === true){
    header("location: login.php");
    exit;
}

// Include database configuration
require_once "db_config.php";

// Function to get user name from user id
function getUserName($mysqli, $userId) {
    // Check if $userId is not empty
    if (!empty($userId)) {
        $sql = "SELECT name FROM user WHERE id = $userId";
        $result = mysqli_query($mysqli, $sql);
        $row = mysqli_fetch_assoc($result);
        return isset($row['name']) ? $row['name'] : "";
    } else {
        return "";
    }
}

// Function to display toast messages
function displayToast($message, $type) {
    echo "<script>
            $(document).ready(function(){
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    onOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });

                Toast.fire({
                    icon: '$type',
                    title: '$message'
                });
            });
        </script>";
}

// Check if delete button is clicked
if(isset($_POST["delete_id"])) {
    $delete_id = $_POST["delete_id"];
    $sql_delete = "DELETE FROM student WHERE id = $delete_id";
    if(mysqli_query($mysqli, $sql_delete)) {
        displayToast('Student record deleted successfully.', 'success');
    } else {
        displayToast('Error deleting record: ' . mysqli_error($mysqli), 'error');
    }
}

// Check if edit form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["edit_id"])) {
    $edit_id = $_POST["edit_id"];
    $name = $_POST["edit_name"];
    $cgpa = $_POST["edit_cgpa"];
    $arrearCount = $_POST["edit_arrearCount"];
    $updatedBy = $_SESSION["user_id"];

    $sql_update = "UPDATE student SET name = '$name', cgpa = $cgpa, arrear_count = $arrearCount, updated_by = $updatedBy WHERE id = $edit_id";
    if(mysqli_query($mysqli, $sql_update)) {
        displayToast('Student record updated successfully.', 'success');
    } else {
        displayToast('Error updating record: ' . mysqli_error($mysqli), 'error');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<div class="container mt-5">
    <a href="add_student.php" class="btn btn-primary mr-2">Add Student</a> 
    <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
    <a href="logout.php" class="btn btn-danger">Logout</a><br><br>
    <h2>Student List</h2>
    <table id="studentTable" class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>Action</th>
            <th>Name</th>
            <th>Roll Number</th>
            <th>CGPA</th>
            <th>No of Arrears</th>
            <th>Created Date Time</th>
            <th>Updated Date Time</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM student WHERE created_by = ".$_SESSION['user_id']." ORDER BY created_datetime DESC";
        $result = mysqli_query($mysqli, $sql);
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>
                        <center>
                            <a href='student_track_record_list.php?filter_by=student&stu_id={$row['id']}&stu_name={$row['name']}' class='btn btn-primary btn-sm' style='margin-bottom: 5px;'>Track Report</a>
                            <button class='btn btn-info btn-sm editBtn' data-id='{$row['id']}' data-name='{$row['name']}' data-cgpa='{$row['cgpa']}' data-arrears='{$row['arrear_count']}' data-toggle='modal' data-target='#editModal'><i class='fas fa-edit'></i></button>
                            <button class='btn btn-danger btn-sm deleteBtn' data-id='{$row['id']}' data-toggle='modal' data-target='#deleteModal'><i class='fas fa-trash'></i></button>
                        </center>
                    </td>
                    <td>{$row['name']}</td>
                    <td>{$row['roll_number']}</td>
                    <td>{$row['cgpa']}</td>
                    <td>{$row['arrear_count']}</td>
                    <td>{$row['created_datetime']}</td>
                    <td>{$row['updated_datetime']}</td>
                    
                  </tr>";
        }
        ?>
        </tbody>
    </table>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Student</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editForm" method="post">
                    <div class="form-group">
                        <label for="edit_name">Name:</label>
                        <input type="text" class="form-control" id="edit_name" name="edit_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_cgpa">CGPA:</label>
                        <input type="text" class="form-control" id="edit_cgpa" placeholder="Enter CGPA" name="edit_cgpa" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_arrearCount">Arrear Count:</label>
                        <input type="number" class="form-control" id="edit_arrearCount" name="edit_arrearCount" required>
                    </div>
                    <input type="hidden" id="edit_id" name="edit_id">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Delete Student</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this student?</p>
            </div>
            <div class="modal-footer">
                <form id="deleteForm" method="post">
                    <input type="hidden" id="delete_id" name="delete_id">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#studentTable').DataTable({
            "searching": false, // Disable search
            "ordering": false // Disable sorting
        });

        // Edit button click
        $(document).on('click', '.editBtn', function(){
            $('#edit_id').val($(this).data('id'));
            $('#edit_name').val($(this).data('name'));
            $('#edit_cgpa').val($(this).data('cgpa'));
            $('#edit_arrearCount').val($(this).data('arrears'));
        });

        // Delete button click
        $(document).on('click', '.deleteBtn', function(){
            $('#delete_id').val($(this).data('id'));
        });

        // Form validation for edit form
        $('#editForm').submit(function(e){
            var cgpa = $('#edit_cgpa').val();
            var arrears = $('#edit_arrearCount').val();

            if(isNaN(cgpa) || cgpa == '' || isNaN(arrears) || arrears == '') {
                e.preventDefault();
                alert('Please enter valid CGPA and arrear count.');
            }
        });
    });
</script>

</body>
</html>
