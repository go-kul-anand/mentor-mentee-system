<?php
    session_start();
    $name = "";
    $department = "";
    // Check if user is logged in
    if (isset($_SESSION['user_id'])) {
        $name = $_SESSION['name'];
        $department = $_SESSION['department'];
    } else {
        // Redirect if user is not logged in
        header("Location: login.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
</head>
<body>  
    <?php require_once "./bytes/header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 mt-5">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Mentor Dashboard</h3>
                    </div>
                    <div class="card-body">
                        <?php 
                            echo "<p>Welcome, $name!</p>";
                            echo "<p>Department: $department</p>";
                        ?>
                        <!-- Buttons for various actions -->
                        <div class="text-center">
                            <!-- PHP href navigation -->
                            <a href="student_list.php" class="btn btn-success mr-2">Student Management</a>
                            <a href="student_track_record_list.php?filter_by=none" class="btn btn-warning">Student Track Record Management</a>
                            <br><br>
                            <a href="logout.php" class="btn btn-secondary">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>
</html>
