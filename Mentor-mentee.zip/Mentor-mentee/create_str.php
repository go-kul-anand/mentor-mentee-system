<?php
    session_start();

    // Check if user is not logged in, redirect to login page
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    // Include the database configuration file
    require_once "db_config.php";

    // Initialize an empty array to store the result
    $result_array = [];

    // Fetch mode and gen_id from query parameters
    $mode = $_GET["mode"];
    $gen_id = '';

    // Check if mode is "view"
    if ($mode === "view" || $mode === "edit") {

        $gen_id = $_GET["gen_id"];
        // Fetch data from student_track_record where generated_id matches gen_id
        $sql = "SELECT * FROM student_track_record WHERE generated_id = '$gen_id'";
        $result = mysqli_query($mysqli, $sql);

        // Check if any record found
        if (mysqli_num_rows($result) > 0) {
            // Fetch associated records from student_record_details
            $row = mysqli_fetch_assoc($result);
            $str_id = $row['id'];
            $sql_details = "SELECT * FROM student_record_details WHERE str_id = '$str_id'";
            $result_details = mysqli_query($mysqli, $sql_details);
            
            // Add main record to the result array
            $result_array['main_record'] = $row;

            // Initialize an array to store associated details
            $details_array = [];

            // Iterate through associated records
            while ($detail_row = mysqli_fetch_assoc($result_details)) {
                // Push each detail record to the details array
                $details_array[] = $detail_row;
            }

            // Add associated details to the result array
            $result_array['details'] = $details_array;
        }

    } elseif ($mode === "create") {
        // Show alert for create mode
        // echo "<script>alert('Creating new student track record.');</script>";
    }

    // Convert the result array to JSON format
    $json_data = json_encode($result_array);
?>

<!-- Access the JSON data in your HTML tags -->
<input type="hidden" id="mode_data" value="<?php echo $mode; ?>">
<input type="hidden" id="json_data" value="<?php echo htmlspecialchars($json_data); ?>">

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentor Mentee System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <style>
        #counseling {
            box-sizing: border-box;
        }

        #counseling::before {
            content: attr(placeholder);
            color: rgb(122, 115, 115);
            position: absolute;
            pointer-events: none;
            user-select: none;
            display: none;
        }

        #counseling:empty::before {
            display: block;
        }

        table,
        th,
        td {
            border: 10px solid #ddd;
        }

        th,
        td {
            padding: 10px;
            /* width: 10%; */
            text-align: center;
        }

        th {
            /* width: 10%; */
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>

    <div class="container mt-5">
        <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
        <a href="student_track_record_list.php?filter_by=none" class="btn btn-primary mr-2">Student Track Record List</a> 
        <a href="logout.php" class="btn btn-danger">Logout</a><br><br>
        <h2 class="text-center mb-4">Student Track Record (STR)</h2>
        <!-- Mentor Details Section -->
        <div class="row mb-4">
            <?php if ($mode !== "view"): ?>
                <div class="col-md-12">
                    <label for="NameoftheMentor">Student Track Record ID: <?php echo $gen_id; ?></label>
                </div>
            <?php endif; ?>

            <div class="col-md-12">
                <label for="NameoftheMentor">Department: <?php echo ($mode === "create" || $mode === "edit") ? $_SESSION['department'] : "";?><span id="department_span"></span></label>
                <input type="hidden" id="department" placeholder="Department" value="<?php echo ($mode === "create" || $mode === "edit") ? $_SESSION['department'] : "";?>">
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="NameoftheMentor">Name of the Mentor:</label>
                    <input type="text" class="form-control" id="NameoftheMentor" value="<?php echo ($mode === "create" || $mode === "edit") ? $_SESSION['name'] : "";?>"
                        disabled>
                </div>
                <!-- Add other mentor details here -->
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Class">Class:</label>
                    <input type="text" class="form-control" id="Class" <?php echo ($mode === "view") ? "disabled" : ""; ?>>
                </div>
                <!-- Add other mentor details here -->
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Batch">Batch:</label>
                    <select id="Batch" class="form-control" <?php echo ($mode === "view") ? "disabled" : ""; ?>>
                        <option value="select">Select</option>
                        <option value="2020-2024">2020-2024</option>
                        <option value="2021-2025">2021-2025</option>
                        <option value="2022-2026">2022-2026</option>
                        <option value="2023-2027">2023-2027</option>
                        <option value="2024-2028">2024-2028</option>
                        <option value="2025-2029">2025-2029</option>
                        <option value="2026-2030">2026-2030</option>
                        <option value="2027-2031">2027-2031</option>
                        <option value="2028-2032">2028-2032</option>
                        <option value="2029-2033">2029-2033</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="designation">Mentor Designation:</label>
                    <input type="text" class="form-control" id="designation" <?php echo ($mode === "view") ? "disabled" : ""; ?>>
                </div>
                <!-- Add other mentor details here -->
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Semester">Semester:</label>
                    <select id="Semester" class="form-control" <?php echo ($mode === "view") ? "disabled" : ""; ?>>
                        <option value="select">Select</option>
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                        <option value="6">Semester 6</option>
                        <option value="7">Semester 7</option>
                        <option value="8">Semester 8</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="academicYear">Academic Year:</label>
                    <select id="academicYear" class="form-control" <?php echo ($mode === "view") ? "disabled" : ""; ?>>
                        <option value="select">Select</option>
                        <option value="2023-2024">2023-2024</option>
                        <option value="2024-2025">2024-2025</option>
                        <option value="2025-2026">2025-2026</option>
                        <option value="2026-2027">2026-2027</option>
                        <option value="2027-2028">2027-2028</option>
                        <option value="2028-2029">2028-2029</option>
                        <option value="2029-2030">2029-2030</option>
                        <option value="2030-2031">2030-2031</option>
                        <option value="2031-2032">2031-2032</option>
                        <option value="2032-2033">2032-2033</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Student Details Section -->
        <div class="row mb-4">
            <div class="col-md-12">
                <h3 class="text-center mb-3">Student Details</h3>
                <table id="studentsTable">
                    <tr>
                        <th>Roll Number</th>
                        <th>Name</th>
                        <th>CGPA</th>
                        <th>No. of Arrear(s)</th>
                        <th>Paper Presentation/ Technical event/Quiz</th>
                        <th>Project / Hackathon</th>
                        <th>Extracurricular Activities (Sports / Club / NSS / NCC / Others)</th>
                        <th>Online Certifications (Coursera / EDx / NPTEL / Others)</th>
                        <th>Counseling</th>
                        <th>Signature of Student with Date</th>
                        <?php if ($mode === "edit"): ?><th>Action</th><?php endif; ?>
                    </tr>
                </table>
            </div>
        </div>

        <div class="row mb-4" id="fetchStudentDivision">
            <div class="col-md-12 mb-3">
                <div class="form-group">
                    <!-- <label for="rollNumberToFetch">Roll Number:</label> -->
                    <input type="number" class="form-control" id="rollNumberToFetch" placeholder="Enter roll number to fetch details" name="rollNumber">
                </div>
                <button class="btn btn-primary" onclick="fetchStudentDetails()">Fetch Student Details</button>
            </div>
        </div>
        <div class="row mb-4" id="addStudentDivision">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="rollNumber">Roll Number: <span id="rollNumberSpan"></span></label>
                    <input type="hidden" class="form-control" id="rollNumber" placeholder="RollNumber" readonly>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="studentName">Name: <span id="studentNameSpan"></span></label>
                    <input type="hidden" class="form-control" id="studentName" placeholder="Name" readonly>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="cgpa">CGPA: <span id="cgpaSpan"></span></label>
                    <input type="hidden" class="form-control" id="cgpa" placeholder="CGPA" readonly>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="noofarrears">No of Arrear(s): <span id="noofarrearsSpan"></span></label>
                    <input type="hidden" class="form-control" id="noofarrears" placeholder="No. of Arrear(s)" readonly>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" class="form-control" id="paperpresentationtechnicaleventquiz" placeholder="Paper Presentation/Technical event/Quiz (Use Only Numbers)" oninput="formatInput(this)">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" class="form-control" id="projectorhackthaon" placeholder="Project/Hackathon" oninput="formatInput(this)">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" class="form-control" id="extracurricularactivites" placeholder="Extracurricular Activities (Sports/Club/NSS/NCC/Others)">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" class="form-control" id="onlinecertification" placeholder="Online Certification (Coursera/EDx/NPTEL/Others)" oninput="formatInput2(this)">
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="form-group">
                    <div id="counseling" contenteditable="true"
                    class="form-control"
                    style="min-height: 38px; text-align: left;"
                    placeholder="Counseling (Press enter for bullet points)"></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input type="text" class="form-control" id="signatureofstudent" placeholder="Signature of Student">
                </div>
            </div>
            <div class="col-md-12 mb-3">
                <button class="btn btn-danger" onclick="addStudent()">Add Student</button>
            </div>
        </div>


        <!-- Overall Observation(s) and Action Taken Section -->
        <div class="row mb-4">
            <div class="col-md-6">
                <h3>Overall Observation(s)</h3>
                <div class="form-group">
                    <textarea class="form-control" id="overallObservations" rows="5"
                        placeholder="Enter overall observations" <?php echo ($mode === "view") ? "disabled" : ""; ?>></textarea>
                </div>
            </div>
            <div class="col-md-6">
                <h3>Action Taken</h3>
                <div class="form-group">
                    <textarea class="form-control" id="actionTaken" rows="5"
                        placeholder="Enter action taken" <?php echo ($mode === "view") ? "disabled" : ""; ?>></textarea>
                </div>
            </div>
        </div>

        <!-- Export to PDF Button -->
        <div class="row mb-5">
            <?php if ($mode === "create"): ?>
                <div class="col-md-6 text-center">
                    <button class="btn btn-success" onclick="addStudentTrackRecord()">Add Student Track Record</button>
                </div>
            <?php endif; ?>
            <?php if ($mode === "edit"): ?>
                <div class="col-md-6 text-center">
                    <button class="btn btn-success" onclick="addStudentTrackRecord()">Update Student Track Record</button>
                </div>
            <?php endif; ?>
            <?php if ($mode === "view"): ?>
            <div class="col-md-6 text-center">
                <button class="btn btn-warning" onclick="exporttoPDF()">Export to PDF</button>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirmation</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this student?</p>
                </div>
                <div class="modal-footer">
                    <form id="deleteForm" method="post">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.6/jspdf.plugin.autotable.min.js"></script>
    
    
    <script>
        window.onload = function() {
            document.getElementById('addStudentDivision').classList.add("d-none");
        }
            var mode = $("#mode_data").val()
            var jsonData = JSON.parse($("#json_data").val());
            if (mode == "view") {
                document.getElementById('fetchStudentDivision').classList.add("d-none");

                // Check if main record exists
                if (jsonData.hasOwnProperty('main_record')) {
                    // Set value for CGPA input field
                    document.getElementById('department_span').innerHTML = jsonData.main_record.department;
                    $("#department").val(jsonData.main_record.department);
                    $("#NameoftheMentor").val(jsonData.main_record.mentor_name);
                    
                    $("#Class").val(jsonData.main_record.class);
                    $("#Batch").val(jsonData.main_record.batch);
                    $("#designation").val(jsonData.main_record.mentor_designation);
                    $("#Semester").val(jsonData.main_record.semester);
                    $("#academicYear").val(jsonData.main_record.academic_year);

                    $("#overallObservations").val(jsonData.main_record.overall_observation);
                    $("#actionTaken").val(jsonData.main_record.action_taken);
                    
                    // Check if details array exists
                    if (jsonData.hasOwnProperty('details')) {
                        // Iterate over details array and add rows to the table
                        jsonData.details.forEach(function(detail) {
                            var table = document.getElementById('studentsTable');
                            var row = table.insertRow(-1);
                            var cell1 = row.insertCell(0);
                            var cell2 = row.insertCell(1);
                            var cell3 = row.insertCell(2);
                            var cell4 = row.insertCell(3);
                            var cell5 = row.insertCell(4);
                            var cell6 = row.insertCell(5);
                            var cell7 = row.insertCell(6);
                            var cell8 = row.insertCell(7);
                            var cell9 = row.insertCell(8);
                            var cell10 = row.insertCell(9);

                            cell1.innerHTML = detail.roll_number;
                            cell2.innerHTML = detail.name;
                            cell3.innerHTML = detail.cgpa;
                            cell4.innerHTML = detail.num_arrears;
                            cell5.innerHTML = detail.paper_presentation;
                            cell6.innerHTML = detail.project_hackathon;
                            cell7.innerHTML = detail.extracurricular_activities;
                            cell8.innerHTML = detail.online_certifications;
                            cell9.innerHTML = detail.counseling.replace(/\n/g, "<br>");
                            cell10.innerHTML = detail.signature_of_student;
                        });
                    }

                }
            } else if (mode == "edit") {

                // Check if main record exists
                if (jsonData.hasOwnProperty('main_record')) {
                    // Set value for CGPA input field
                    document.getElementById('department_span').innerHTML = jsonData.main_record.department;
                    $("#department").val(jsonData.main_record.department);
                    $("#NameoftheMentor").val(jsonData.main_record.mentor_name);
                    
                    $("#Class").val(jsonData.main_record.class);
                    $("#Batch").val(jsonData.main_record.batch);
                    $("#designation").val(jsonData.main_record.mentor_designation);
                    $("#Semester").val(jsonData.main_record.semester);
                    $("#academicYear").val(jsonData.main_record.academic_year);

                    $("#overallObservations").val(jsonData.main_record.overall_observation);
                    $("#actionTaken").val(jsonData.main_record.action_taken);
                    
                    // Check if details array exists
                    if (jsonData.hasOwnProperty('details')) {
                        // Iterate over details array and add rows to the table
                        jsonData.details.forEach(function(detail) {
                            var table = document.getElementById('studentsTable');
                            var row = table.insertRow(-1);
                            var cell1 = row.insertCell(0);
                            var cell2 = row.insertCell(1);
                            var cell3 = row.insertCell(2);
                            var cell4 = row.insertCell(3);
                            var cell5 = row.insertCell(4);
                            var cell6 = row.insertCell(5);
                            var cell7 = row.insertCell(6);
                            var cell8 = row.insertCell(7);
                            var cell9 = row.insertCell(8);
                            var cell10 = row.insertCell(9);
                            var cell11 = row.insertCell(10);

                            cell1.innerHTML = detail.roll_number;
                            cell2.innerHTML = detail.name;
                            cell3.innerHTML = detail.cgpa;
                            cell4.innerHTML = detail.num_arrears;
                            cell5.innerHTML = detail.paper_presentation;
                            cell6.innerHTML = detail.project_hackathon;
                            cell7.innerHTML = detail.extracurricular_activities;
                            cell8.innerHTML = detail.online_certifications;
                            cell9.innerHTML = detail.counseling.replace(/\n/g, "<br>");
                            cell10.innerHTML = detail.signature_of_student;
                            cell11.innerHTML = "<button class='btn btn-danger btn-sm deleteBtn' data-roll_number='" + detail.roll_number + "' data-row_index='" + row.rowIndex + "' data-bs-toggle='modal' data-bs-target='#deleteModal'><i class='fas fa-trash'></i></button>";


                        });
                    }

                }

            }
        
            function formatInput(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 1) {
                    value = value.slice(0, 1) + '/' + value.slice(1);
                }
                if (value.length > 3) {
                    value = value.slice(0, 3) + '/' + value.slice(3);
                }
                input.value = value;
            }

            function formatInput2(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 1) {
                    value = value.slice(0, 1) + '/' + value.slice(1);
                }
                if (value.length > 3) {
                    value = value.slice(0, 3) + '/' + value.slice(3);
                }
                if (value.length > 5) {
                    value = value.slice(0, 5) + '/' + value.slice(5);
                }
                input.value = value;
            }

            document.getElementById('counseling').addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    var listItem = document.createElement('div');
                    listItem.innerHTML = '&bull;&nbsp;';
                    this.appendChild(listItem);
                    placeCaretAtEnd(listItem);
                }
            });

            function placeCaretAtEnd(el) {
                el.focus();
                if (typeof window.getSelection != "undefined" && typeof document.createRange != "undefined") {
                    var range = document.createRange();
                    range.selectNodeContents(el);
                    range.collapse(false);
                    var sel = window.getSelection();
                    sel.removeAllRanges();
                    sel.addRange(range);
                } else if (typeof document.body.createTextRange != "undefined") {
                    var textRange = document.body.createTextRange();
                    textRange.moveToElementText(el);
                    textRange.collapse(false);
                    textRange.select();
                }
            }

            document.querySelectorAll('.editable-div').forEach(div => {
                div.addEventListener('keydown', function(event) {
                    if (event.key === "Enter" && !event.shiftKey) {
                        event.preventDefault();
                        var selection = window.getSelection();
                        var range = selection.getRangeAt(0);
                        var startNode = range.startContainer;
                        var startOffset = range.startOffset;

                        if (startOffset === 0 || (startNode.nodeType === 3 && startNode.nodeValue.charAt(startOffset - 1) === "\n")) {
                            document.execCommand('insertHTML', false, '• ');
                        } else {
                            document.execCommand('insertHTML', false, '<br>• ');
                        }
                    }
                });
            });
            
            function showTab(tabName) {
                document.getElementById('studentsTab').style.display = (tabName === 'students') ? 'block' : 'none';
            }
            function showTab(tabName) {
                var departmentSelect = document.getElementById('department');
                
                document.getElementById('studentsTab').style.display = (tabName === 'students') ? 'block' : 'none';
            }
            
            function addStudent() {
                
                var rollNumber = document.getElementById('rollNumber').value;
                if (rollNumber === '') {
                    alert('Please enter a roll number.');
                    return;
                }

                var studentName = document.getElementById('studentName').value;

                var cgpa = document.getElementById('cgpa').value;

                var noofarrears = document.getElementById('noofarrears').value;

                var paperpresentationtechnicaleventquiz = document.getElementById('paperpresentationtechnicaleventquiz').value;
                if (paperpresentationtechnicaleventquiz === '') {
                    alert('Please enter PPT / Technical Event / Quiz.');
                    return;
                }

                var projectHackathon = document.getElementById('projectorhackthaon').value;
                if (projectHackathon === '') {
                    alert('Please enter a Project / Hackathon.');
                    return;
                }

                var extracurricularactivites = document.getElementById('extracurricularactivites').value;
                if (extracurricularactivites === '') {
                    alert('Please enter Extra Curricular Activities.');
                    return;
                }

                var onlinecertification = document.getElementById('onlinecertification').value;
                if (onlinecertification === '') {
                    alert('Please enter Online Certification.');
                    return;
                }

                var counselingDiv = document.getElementById('counseling');

                var counselingNodes = counselingDiv.childNodes;
                var counselingContent = '';

                for (var i = 0; i < counselingNodes.length; i++) {
                    if (counselingNodes[i].nodeName === 'DIV') {
                        counselingContent += '' + counselingNodes[i].innerText.trim() + '<br>';
                    } else if (counselingNodes[i].nodeName === 'BR') {
                        counselingContent += '<br>';
                    }
                }

                var counseling = counselingContent;
                if (counseling === '') {
                    alert('Please enter Counselling.');
                    return;
                }

                var signatureofstudent = document.getElementById('signatureofstudent').value;
                

                var table = document.getElementById('studentsTable');
                var row = table.insertRow(-1);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);
                var cell7 = row.insertCell(6);
                var cell8 = row.insertCell(7);
                var cell9 = row.insertCell(8);
                var cell10 = row.insertCell(9);

                cell1.innerHTML = rollNumber;
                cell2.innerHTML = studentName;
                cell3.innerHTML = cgpa;
                cell4.innerHTML = noofarrears;
                cell5.innerHTML = paperpresentationtechnicaleventquiz;
                cell6.innerHTML = projectHackathon;
                cell7.innerHTML = extracurricularactivites;
                cell8.innerHTML = onlinecertification;
                cell9.innerHTML = counseling;
                cell10.innerHTML = signatureofstudent;

                if (mode == "edit") {

                    var cell11 = row.insertCell(10);
                    cell11.innerHTML = "<button class='btn btn-danger btn-sm deleteBtn' data-roll_number='" + rollNumber + "' data-row_index='" + row.rowIndex + "' data-bs-toggle='modal' data-bs-target='#deleteModal'><i class='fas fa-trash'></i></button>";


                }

                resetFields();
                document.getElementById('addStudentDivision').classList.add("d-none");
                alert("student added successfully");
            }

            function fetchStudentDetails() {
                var rollNumber = document.getElementById('rollNumberToFetch').value;
                if (rollNumber === '') {
                    alert('Please enter a roll number.');
                    return;
                }

                // AJAX request to fetch student data
                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'fetch_student_data.php?roll_number=' + rollNumber, true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        var studentData = JSON.parse(xhr.responseText);
                        if (studentData.success) {
                            // If data is fetched successfully, add student row
                            document.getElementById('rollNumberSpan').innerHTML += rollNumber;
                            document.getElementById('rollNumber').value = rollNumber;

                            document.getElementById('studentNameSpan').innerHTML += studentData.name;
                            document.getElementById('studentName').value = studentData.name;

                            document.getElementById('cgpaSpan').innerHTML += studentData.cgpa;
                            document.getElementById('cgpa').value = studentData.cgpa;

                            document.getElementById('noofarrearsSpan').innerHTML += studentData.arrears;
                            document.getElementById('noofarrears').value = studentData.arrears;

                            // Clear input field after adding student
                            document.getElementById('rollNumberToFetch').value = '';

                            document.getElementById('addStudentDivision').classList.remove("d-none");
                        } else {
                            alert('Student data not available');
                        }
                    } else {
                        alert('Error fetching student data. Please try again.');
                    }
                };
                xhr.send();
            }



            function resetFields() {
                
                document.getElementById('rollNumberSpan').innerHTML = '';
                document.getElementById('studentNameSpan').innerHTML = '';
                document.getElementById('cgpaSpan').innerHTML = '';
                document.getElementById('noofarrearsSpan').innerHTML = '';

                document.getElementById('rollNumber').value = '';
                document.getElementById('studentName').value = '';
                document.getElementById('cgpa').value = '';
                document.getElementById('noofarrears').value = '';
                document.getElementById('paperpresentationtechnicaleventquiz').value = '';
                document.getElementById('projectorhackthaon').value = '';
                document.getElementById('extracurricularactivites').value = '';
                document.getElementById('onlinecertification').value = '';
                document.getElementById('counseling').innerHTML = '';
                document.getElementById('signatureofstudent').value = '';
            }

            function addStudentTrackRecord() {
                // Generate a unique ID for the student track record (you can use a combination of prefix and a random 6-digit code)
                var generatedId = "";

                var department = document.getElementById('department').value;
                if (department === 'select') {
                    alert('Please select a valid department before exporting.');
                    return;
                }

                var mentorName = document.getElementById('NameoftheMentor').value;
                if (!mentorName.trim()) {
                    alert('Please enter a mentor name.');
                    return;
                }

                var mentorDesignation = document.getElementById('designation').value;
                if (!mentorDesignation.trim()) {
                    alert('Please enter a mentor designation.');
                    return;
                }

                var classValue = document.getElementById('Class').value;
                if (!classValue.trim()) {
                    alert('Please enter a class.');
                    return;
                }

                var batch = document.getElementById('Batch').value;
                if (batch === 'select') {
                    alert('Please enter a batch.');
                    return;
                }

                var semester = document.getElementById('Semester').value;
                if (semester === 'select') {
                    alert('Please enter a semester.');
                    return;
                }

                var academicYear = document.getElementById('academicYear').value;
                if (academicYear === 'select') {
                    alert('Please enter an academic year.');
                    return;
                }

                var overallObservation = document.getElementById('overallObservations').value;
                if (!overallObservation.trim()) {
                    alert('Please enter overall observations.');
                    return;
                }

                var actionTaken = document.getElementById('actionTaken').value;
                if (!actionTaken.trim()) {
                    alert('Please enter action taken.');
                    return;
                }

                // Get the total number of students from the table
                var table = document.getElementById('studentsTable');
                var rows = table.getElementsByTagName('tr');
                var totalNumberOfStudents = rows.length - 1; // Subtract 1 for the header row

                if (totalNumberOfStudents === 0) {
                    alert('Please add at least one student to the table.');
                    return;
                }

                var updStrId = 0;
                if (mode == "edit") {
                    updStrId = jsonData.main_record.id;
                    generatedId = jsonData.main_record.generated_id;
                } else if (mode == "create") {
                    generatedId = generateUniqueId();
                }

                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'insert_student_track_record.php', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            var strId = 0;
                            if(mode=="create") {
                                strId = JSON.parse(xhr.responseText).strId;
                            } else if(mode=="edit") {
                                strId = updStrId;
                            }
                            
                            addStudentDetails(strId);
                        } else {
                            console.error('Error occurred while adding student track record');
                        }
                    }
                };

                var data = JSON.stringify({
                    updStrId: updStrId,
                    action: mode,
                    generatedId: generatedId,
                    department: department,
                    mentorName: mentorName,
                    mentorDesignation: mentorDesignation,
                    class: classValue,
                    batch: batch,
                    semester: semester,
                    academicYear: academicYear,
                    overallObservation: overallObservation,
                    actionTaken: actionTaken,
                    totalNumberOfStudents: totalNumberOfStudents
                });

                xhr.send(data);
                
            }

            function addStudentDetails(strId) {
                var table = document.getElementById('studentsTable');
                var rows = table.getElementsByTagName('tr');

                // Start loop from index 1 to skip the header row
                for (var i = 1; i < rows.length; i++) {
                    var cells = rows[i].getElementsByTagName('td');

                    // Retrieve student details from each cell of the row
                    var rollNumber = cells[0].innerText;
                    var studentName = cells[1].innerText;
                    var cgpa = cells[2].innerText;
                    var numArrears = cells[3].innerText;
                    var paperPresentation = cells[4].innerText;
                    var projectHackathon = cells[5].innerText;
                    var extracurricularActivities = cells[6].innerText;
                    var onlineCertifications = cells[7].innerText;
                    var counseling = cells[8].innerText;
                    var signatureOfStudent = cells[9].innerText;

                    // Prepare data for insertion
                    var data = JSON.stringify({
                        strId: strId,
                        rollNumber: rollNumber,
                        studentName: studentName,
                        cgpa: cgpa,
                        numArrears: numArrears,
                        paperPresentation: paperPresentation,
                        projectHackathon: projectHackathon,
                        extracurricularActivities: extracurricularActivities,
                        onlineCertifications: onlineCertifications,
                        counseling: counseling,
                        signatureOfStudent: signatureOfStudent
                    });

                    // Create a closure to capture the current value of 'i'
                    (function(index) {
                        // Perform AJAX request to insert student details
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', 'insert_student_details.php', true);
                        xhr.setRequestHeader('Content-Type', 'application/json');
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === XMLHttpRequest.DONE) {
                                if (xhr.status === 200) {
                                    // Check if this is the last iteration
                                    if (index === rows.length - 1) {
                                        // Student details added successfully
                                        alert('Student details added successfully!');
                                        // Reset input fields and remove inserted rows
                                        clearForm();
                                        // Redirect to student_track_record_list.php
                                        window.location.href = 'student_track_record_list.php?filter_by=none';
                                    }
                                } else {
                                    // Handle error
                                    console.error('Error occurred while adding student details');
                                    // If any failure occurs, delete the record from student_track_record using strId
                                    deleteRecord(strId);
                                }
                            }
                        };
                        xhr.send(data);
                    })(i); // Pass 'i' as an argument to the closure

                }
            }

            // Handle Delete Button Click
            $('.deleteBtn').click(function() {
                var rowIndex = $(this).data('row_index');
                $('#confirmDeleteBtn').attr('data-row_index', rowIndex);
                $('#deleteModal').modal('show'); // Show the modal
            });

            // Handle Confirm Delete Button Click
            $('#confirmDeleteBtn').click(function() {
                // Get the rowIndex from the data attribute
                var rowIndex = $(this).data('row_index');
                
                // Remove the row with the specified rowIndex
                $('#studentsTable tbody tr').eq(rowIndex).remove();

                // Hide the delete modal
                $('#deleteModal').modal('hide');
            });



            // Function to clear the form fields and remove inserted rows
            function clearForm() {
                // Clear input fields
                document.getElementById('designation').value = '';
                document.getElementById('Class').value = '';
                document.getElementById('Batch').value = '';
                document.getElementById('Semester').value = '';
                document.getElementById('academicYear').value = '';
                document.getElementById('overallObservations').value = '';
                document.getElementById('actionTaken').value = '';

                // Remove inserted rows from the table
                var table = document.getElementById('studentsTable');
                var rows = table.getElementsByTagName('tr');
                for (var i = rows.length - 1; i > 0; i--) {
                    table.deleteRow(i);
                }
            }


            // Function to generate a unique ID for the student track record
            function generateUniqueId() {
                // Implementation of generating a unique ID (prefix + random 6-digit code)
                // Example: "STR123456"
                var prefix = "STR";
                var randomCode = Math.floor(100000 + Math.random() * 900000);
                return prefix + randomCode;
            }


            function exporttoPDF() {
                var department = document.getElementById('department').value;
                if (department === 'select') {
                    alert('Please select a valid department before exporting.');
                    return;
                }
                var pdf = new jsPDF({ format: 'a4', orientation: 'landscape', unit: 'cm', lineHeight: 1 });
                pdf.setFontSize(12);
                var NameoftheMentor = document.getElementById('NameoftheMentor').value;
                var designation = document.getElementById('designation').value;
                const academicYear = document.getElementById('academicYear').value;
                var Class = document.getElementById('Class').value;
                const semester = document.getElementById('Semester').value;
                const batch = document.getElementById('Batch').value;

                if (!NameoftheMentor || !designation || !academicYear || !Class || !semester || !batch) {
                    alert("Please fill in all mentor details before adding student details.");
                    return;
                }
                const leftX = 3;
                const rightX = 20;
                const title = "Mentor Mentee System - Student Track Record(STR)";
                const titleX = (pdf.internal.pageSize.width - pdf.getStringUnitWidth(title) * pdf.internal.getFontSize() / pdf.internal.scaleFactor) / 2;
                pdf.text(title, titleX, 7);
                const departmentTextWidth = pdf.getStringUnitWidth(department) * pdf.internal.getFontSize() / pdf.internal.scaleFactor;
                const departmentX = (pdf.internal.pageSize.width - departmentTextWidth) / 2;

                pdf.text(department, departmentX, 8);
                pdf.text(`Name of the Mentor : ${NameoftheMentor}`, leftX, 9);
                pdf.text(`Designation              : ${designation}`, leftX, 10);
                pdf.text(`Academic Year        : ${academicYear}`, leftX, 11);
                pdf.text(`Class       : ${Class}`, rightX, 9);
                pdf.text(`Semester : ${semester}`, rightX, 10);
                pdf.text(`Batch       : ${batch}`, rightX, 11);

                var logoImg = new Image();
                logoImg.src = 'https://i.postimg.cc/cHHdLfZn/Whats-App-Image-2024-01-24-at-7-50-24-PM.jpg';
                const pdfWidth = pdf.internal.pageSize.width;
                pdf.addImage(logoImg, 'JPEG', 1, 1, pdfWidth - 2, 5);

                const tableData2 = [];
                const table = document.getElementById('studentsTable');
                const headersRow = table.rows[0];
                const headers = [];
                for (let i = 0; i < headersRow.cells.length; i++) {
                    headers.push(headersRow.cells[i].innerText.trim());
                }
                tableData2.push(headers);

                for (let i = 1; i < table.rows.length; i++) {
                    const rowData = [];
                    const dataRow = table.rows[i];
                    for (let j = 0; j < dataRow.cells.length; j++) {
                        rowData.push(dataRow.cells[j].innerText.trim());
                    }
                    tableData2.push(rowData);
                }

                pdf.autoTable({
                    body: tableData2,
                    margin: { top: 2, right: 2, bottom: 4, left: 2 },
                    startY: 12,
                    theme: 'plain',
                    styles: {
                        lineWidth: 0.1,
                        valign: 'middle',
                        halign: 'center',
                    },
                    columnStyles: {
                        0: { cellWidth: 2 },
                        1: { cellWidth: 2 },
                        2: { cellWidth: 2 },
                        3: { cellWidth: 2 },
                        4: { cellWidth: 2 },
                        5: { cellWidth: 2 },
                        6: { cellWidth: 3 },
                        7: { cellWidth: 2 },
                        8: { cellWidth: 6, halign: 'left' },
                        9: { cellWidth: 2 }
                    },
                    didParseCell: function (data) {
                        if (data.row.index === 0 && data.column.index === 8) {
                            data.cell.styles.halign = 'left';
                            data.cell.styles.valign = 'middle';
                        }
                    },
                });

                pdf.addPage();
                pdf.setFont('helvetica', 'bold'); // Set font to bold
                pdf.text('Overall Observation(s)', 1, 2);
                pdf.setFont('helvetica', 'normal'); // Reset font to normal
                var overallObservationLines = pdf.splitTextToSize(document.getElementById('overallObservations').value, pdf.internal.pageSize.width - 2);
                for (var i = 0; i < overallObservationLines.length; i++) {
                    pdf.text(overallObservationLines[i], 1, 3 + i);
                }
                pdf.setFont('helvetica', 'bold'); // Set font to bold
                pdf.text('Action Taken', 1, 10);
                pdf.setFont('helvetica', 'normal'); // Reset font to normal
                var actionTakenLines = pdf.splitTextToSize(document.getElementById('actionTaken').value, pdf.internal.pageSize.width - 2);
                for (var i = 0; i < actionTakenLines.length; i++) {
                    pdf.text(actionTakenLines[i], 1, 11 + i);
                }

                pdf.text('Signature of the Mentor with Date', 1, 19);
                pdf.text('Academic Coordinator', 12, 19);
                pdf.text('Head of the Department', 23, 19);

                pdf.save(`Mentor_Mentee_System_STR_${NameoftheMentor}_${academicYear}_${semester}_${Class}.pdf`);
            }
        
    </script>
</body>

</html>
