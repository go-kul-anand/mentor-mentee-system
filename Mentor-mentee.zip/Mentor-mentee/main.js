// Function to show loading overlay
function showLoadingOverlay() {
  document.getElementById("loadingOverlay").classList.remove("d-none");
}

function hideLoadingOverlay() {
  document.getElementById("loadingOverlay").classList.add("d-none");
}
