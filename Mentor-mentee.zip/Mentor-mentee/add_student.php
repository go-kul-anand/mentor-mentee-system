<?php
session_start();

// Redirect user to dashboard if already logged in
if(isset($_SESSION["user_id"]) && $_SESSION["user_id"] === true){
    header("location: login.php");
    exit;
}

// Include database configuration
require_once "db_config.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate form fields
    $name = $_POST["name"];
    $rollNumber = $_POST["rollNumber"];
    $cgpa = $_POST["cgpa"];
    $arrearCount = $_POST["arrearCount"];

    if (empty($name) || empty($rollNumber) || empty($cgpa)) {
        echo "<script>alert('Please fill in all details.');</script>";
    } else {
        // Check if the roll number already exists
        $sql_check = "SELECT * FROM student WHERE roll_number = $rollNumber";
        $result_check = mysqli_query($mysqli, $sql_check);
        if (mysqli_num_rows($result_check) > 0) {
            echo "<script>alert('Roll number already exists.');</script>";
        } else {
            // Insert record into database
            $createdBy = $_SESSION["user_id"];
            $sql_insert = "INSERT INTO student (name, roll_number, cgpa, arrear_count, created_by) 
                           VALUES ('$name', $rollNumber, $cgpa, $arrearCount, $createdBy)";
            if (mysqli_query($mysqli, $sql_insert)) {
                echo "<script>alert('Student record added successfully.');</script>";
                echo "<script>window.location.href = 'student_list.php?filter_by=none';</script>";
                // header("Location: student_list.php");
            } else {
                echo "<script>alert('Error: " . mysqli_error($mysqli) . "');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

 <?php require_once "./bytes/header.php"; ?>

<div class="container login-container mb-5">
    <h3 class="text-center">Add Student</h3>
    <div class="login-form">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="showLoadingOverlay()">
            <div class="mb-3">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" placeholder="Enter name" name="name">
                </div>
            </div>
            <div class="mb-3">
                <div class="form-group">
                    <label for="rollNumber">Roll Number:</label>
                    <input type="number" class="form-control" id="rollNumber" placeholder="Enter roll number" name="rollNumber">
                </div>
            </div>
            <div class="mb-3">
                <div class="form-group">
                    <label for="cgpa">CGPA:</label>
                    <input type="text" class="form-control" id="cgpa" placeholder="Enter CGPA" name="cgpa" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                </div>
            </div>
            <div class="mb-3">
                <div class="form-group">
                    <label for="arrearCount">Arrear Count:</label>
                    <input type="number" class="form-control" id="arrearCount" placeholder="Enter arrear count" name="arrearCount">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="student_list.php" class="btn btn-secondary">Student List</a>
            <a href="index.php" class="btn btn-secondary">Dashboard</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>
