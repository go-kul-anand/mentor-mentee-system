<div id="loadingOverlay" class="position-fixed top-0 start-0 w-100 h-100 bg-white opacity-75 d-none d-flex
    justify-content-center align-items-center" style="z-index: 9999;">
    <!-- Spinner -->
    <div class="spinner-border text-primary" role="status">
        <!-- <span class="visually-hidden">Loading...</span> -->
    </div>
</div>


<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpd4K-pjmQUKAGuVfJ3ynKc7tySLlVX_7Slw&usqp=CAU"
        style="width:150px;height:150px; text-align:center; font-size: 5rem; margin: 18px; float: left; max-width: 100%; max-height: 100%; padding: 1px;">
<img src="https://srec.ac.in/uploads/resource/src/8yeEAIUofd01022018043456srec-logo.jpg"
        style="width:150px;height:150px; text-align:center;font-size: 5rem; float: right; margin: 18px; max-width: 100%; max-height: 100%; padding: 1px;">
<div class="container-fluid" style="background-color:rgb(125, 40, 159)">
        <font color="white" style="font-family:Verdana;font-style:cursive;">
            <h2
                style="text-align: center; padding: 0px ;font-size:50px;background-color:purple;color:transparent;-webkit-text-stroke:1px #fff;background:url(assets/SREC_and_SNR_logo_header_back.png);clip:text;background-position:0 0;animation:back 20s linear infinite;">
                <b>
                    <style>
                        @keyframes back {
                            100% {
                                background-position: 2000px 0;
                            }
                        }
                    </style>
                    <h1 style="font-size:40px" class="flicker">SRI RAMAKRISHNA ENGINEERING COLLEGE</h1>
                    <h4>[Educational Service: SNR Sons Charitable Trust]<br>
                        [Autonomous Institution, Reaccredited by NAAC with ‘A+’ Grade]<br>
                        [Approved by AICTE and Permanently Affiliated to Anna University, Chennai]<br>
                        [ ISO 9001:2015 Certified and all eligible programmes Accredited by NBA]<br>
                        VATTAMALAIPALAYAM, N.G.G.O. COLONY POST, COIMBATORE – 641 022.</h4>
                    <h5>Developed by<br>AI&DS and IQAC</h5>
                    </b>
        </font>
    </div>



<style>


.login-container {
    max-width: 400px;
    margin: 0 auto;
    margin-top: 50px;
}

.login-form {
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
    background-color: #f9f9f9;
}

.footer {
    position: relative;
    left: 0;
    bottom: 0;
    width: 100%;
    color: white;
    text-align: center;
}

.img1 {
    margin: 4px 4px;
}

br body {
    font-family: Verdana;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

br div {
    width: 100%;
    max-width: 1000px;
    background-color: #fff;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    box-sizing: border-box;
}

h2 {
    color: #333;
    text-align: center;
}

button {
    display: block;
    width: 100%;
    padding: 10px;
    background-color: #4caf50;
    color: white;
    border: none;
    cursor: pointer;
    margin-bottom: 10px;
}

button:hover {
    background-color: #45a049;
}

.input-section {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    box-sizing: border-box;
}

.input-section label {
    /* width: calc(32% - 28px); */
    margin-bottom: 5px;
    box-sizing: border-box;
    display: block;
    font-weight: bold;
}

.input-section input {
    /* width: calc(32% - 28px); */
    margin-bottom: 15px;
    box-sizing: border-box;
    padding: 10px;
}

.input-section input[type="button"] {
    width: 100%;
    padding: 10px;
    align-self: center;
}

.display-section {
    margin-top: 20px;
    overflow-x: auto;
}

</style>

<script src="../main.js"></script>