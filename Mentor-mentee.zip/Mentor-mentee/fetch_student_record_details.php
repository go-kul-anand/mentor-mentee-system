<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once "db_config.php";
// Check if recordId is set
if(isset($_GET["recordId"])) {
    $recordId = $_GET["recordId"];

    // Fetch student record details from the database
    $sql = "SELECT * FROM student_record_details WHERE str_id = $recordId";
    $result = mysqli_query($mysqli, $sql);

    // Prepare HTML table with fetched data
    $html = "<thead>
                <tr>
                    <th style='border: 2px solid #000;'>Roll Number</th>
                    <th style='border: 2px solid #000;'>Name</th>
                    <th style='border: 2px solid #000;'>CGPA</th>
                    <th style='border: 2px solid #000;'>Arrears Count</th>
                    <th style='border: 2px solid #000;'>Paper Presentation</th>
                    <th style='border: 2px solid #000;'>Project / Hackathon</th>
                    <th style='border: 2px solid #000;'>Extra Curricular Activities</th>
                    <th style='border: 2px solid #000;'>Online Certification</th>
                    <th style='border: 2px solid #000;'>Counselling</th>
                </tr>
            </thead>
            <tbody>";

    while($row = mysqli_fetch_assoc($result)) {
        $html .= "<tr>
                    <td style='border: 1px solid #000;'>{$row['roll_number']}</td>
                    <td style='border: 1px solid #000;'>{$row['name']}</td>
                    <td style='border: 1px solid #000;'>{$row['cgpa']}</td>
                    <td style='border: 1px solid #000;'>{$row['num_arrears']}</td>
                    <td style='border: 1px solid #000;'>{$row['paper_presentation']}</td>
                    <td style='border: 1px solid #000;'>{$row['project_hackathon']}</td>
                    <td style='border: 1px solid #000;'>{$row['extracurricular_activities']}</td>
                    <td style='border: 1px solid #000;'>{$row['online_certifications']}</td>
                    <td style='border: 1px solid #000;'>" . nl2br($row['counseling']) . "</td>
                </tr>";
    }

    $html .= "</tbody>";

    echo $html;
}

?>
