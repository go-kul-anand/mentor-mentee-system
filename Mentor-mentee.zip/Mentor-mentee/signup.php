<?php
session_start();
 
if(isset($_SESSION["user_id"]) && $_SESSION["user_id"] === true){
    header("location: login.php");
    exit;
}

require_once "db_config.php";

$name = $username = $password = $confirm_password = $department = "";
$name_err = $username_err = $password_err = $confirm_password_err = $department_err = "";

$registration_success = false;

if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    if(empty(trim($_POST["name"]))){
        $name_err = "Please enter your name.";
    } else{
        $name = trim($_POST["name"]);
    }

    if(empty(trim($_POST["department"]))){
        $department_err = "Please Select Department name.";
    } else{
        $department = trim($_POST["department"]);
    }
    
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } else{
        $sql = "SELECT id FROM user WHERE user_name = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("s", $param_username);
            
            $param_username = trim($_POST["username"]);
            
            if($stmt->execute()){
                $stmt->store_result();
                
                if($stmt->num_rows == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            $stmt->close();
        }
    }
    
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have at least 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    if(empty($name_err) && empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($department_err)){
        
        $sql = "INSERT INTO user (name, user_name, password, department) VALUES (?, ?, ?, ?)";
         
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("ssss", $param_name, $param_username, $param_password, $param_department);

            
            $param_name = $name;
            $param_username = $username;
            // $param_password = password_hash($password, PASSWORD_DEFAULT); 
            $param_password = $password; 
            $param_department = $department;
            
            // if($stmt->execute()){
            //     header("location: login.php");
            // } else{
            //     echo "Something went wrong. Please try again later.";
            // }

            if($stmt->execute()){
                $registration_success = true;
            } else{
                echo "Something went wrong. Please try again later.";
            }

            $stmt->close();
        }
    }
    
    $mysqli->close();
}
?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
</head>
<body>
    <h2>Sign Up</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div>
            <label>Name</label>
            <input type="text" name="name" value="<?php echo $name; ?>">
            <span><?php echo $name_err; ?></span>
        </div>    
        <div>
            <label>Username</label>
            <input type="text" name="username" value="<?php echo $username; ?>">
            <span><?php echo $username_err; ?></span>
        </div>
        <div>
            <label>Password</label>
            <input type="password" name="password" value="<?php echo $password; ?>">
            <span><?php echo $password_err; ?></span>
        </div>
        <div>
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" value="<?php echo $confirm_password; ?>">
            <span><?php echo $confirm_password_err; ?></span>
        </div>
        <div>
            <input type="submit" value="Sign Up">
        </div>
        <p>Already have an account? <a href="login.php">Login here</a>.</p>
    </form>
</body>
</html> -->


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php require_once "./bytes/header.php"; ?>
    
    <div class="container login-container">
        <h3 class="text-center">Mentor Mentee System - Student Track Record(STR)</h3>
        <h3 class="text-center">Sign Up</h3>
        <div class="login-form">
            <?php if ($registration_success): ?>
                <div class="alert alert-success" role="alert">
                    Registration successful! You can now.,
                </div>
            <?php else: ?>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" onsubmit="showLoadingOverlay()">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
                        <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($name_err)): ?>
                            <div class="text-danger"><?php echo $name_err; ?></div>
                        <?php endif; ?>
                    </div>  
                    <div class="mb-3">
                        <label for="department" class="form-label">Department</label>
                        <select class="form-select" id="department" name="department" required>
                            <option value="" disabled selected hidden>Select</option>
                            <!-- Options for departments -->
                             <option value="Department of Artificial Intelligence and Data Science" <?php if($department == 'Department of Artificial Intelligence and Data Science') echo 'selected'; ?>>Department of Artificial Intelligence and Data Science</option>
                            <option value="Department of Aeronautical Engineering" <?php if($department == 'Department of Aeronautical Engineering') echo 'selected'; ?>>Department of Aeronautical Engineering</option>
                            <option value="Department of Biomedical Engineering" <?php if($department == 'Department of Biomedical Engineering') echo 'selected'; ?>>Department of Biomedical Engineering</option>
                            <option value="Department of Computer Science Engineering" <?php if($department == 'Department of Computer Science Engineering') echo 'selected'; ?>>Department of Computer Science Engineering</option>
                            <option value="Department of Civil Engineering" <?php if($department == 'Department of Civil Engineering') echo 'selected'; ?>>Department of Civil Engineering</option>
                            <option value="Department of Electronics & Communication Engineering" <?php if($department == 'Department of Electrical & Communication Engineering') echo 'selected'; ?>>Department of Electrical & Communication Engineering</option>
                            <option value="Department of Electrical & Electronics Engineering" <?php if($department == 'Department of Electrical & Electronics Engineering') echo 'selected'; ?>>Department of Electrical & Electronics Engineering</option>
                            <option value="Department of Electronics & Instrumentation Engineering" <?php if($department == 'Department of Electrical & Instrumentation Engineering') echo 'selected'; ?>>Department of Electrical & Instrumentation Engineering</option>
                            <option value="Department of Information Technology" <?php if($department == 'Department of Information Technology') echo 'selected'; ?>>Department of Information Technology</option>
                            <option value="Department of Mechanical Engineering" <?php if($department == 'Department of Mechanical Engineering') echo 'selected'; ?>>Department of Mechanical Engineering</option>
                            <option value="Department of Robotics & Automation" <?php if($department == 'Department of Robotics & Automation') echo 'selected'; ?>>Department of Robotics & Automation</option>
                            <option value="Department of Nano Science and Technology" <?php if($department == 'Department of Nano Science and Technology') echo 'selected'; ?>>Department of Nano Science and Technology</option>
                            <option value="Program-M.Tech Computer Science Engineering" <?php if($department == 'Program-M.Tech Computer Science Engineering') echo 'selected'; ?>>Program-M.Tech Computer Science Engineering</option>
                            <option value="Master of Business Administration (MBA)" <?php if($department == 'Master of Business Administration (MBA)') echo 'selected'; ?>>Master of Business Administration (MBA)</option>
                        </select>
                        <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($department_err)): ?>
                            <div class="text-danger"><?php echo $department_err; ?></div>
                        <?php endif; ?>
                    </div> 
                    <div class="mb-3">
                        <label for="username" class="form-label">User Name</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo $username; ?>" required>
                        <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($username_err)): ?>
                            <div class="text-danger"><?php echo $username_err; ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" value="<?php echo $password; ?>" required>
                        <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($password_err)): ?>
                            <div class="text-danger"><?php echo $password_err; ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" value="<?php echo $confirm_password; ?>" required>
                        <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($confirm_password_err)): ?>
                            <div class="text-danger"><?php echo $confirm_password_err; ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group text-center">
                        <button type="submit" class="btn btn-success">Sign Up</button>
                    </div>
                </form>
            <?php endif; ?>
            <div class="form-group text-center">
                <a href="login.php" class="btn btn-primary">Login</a>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</body>

</html>
